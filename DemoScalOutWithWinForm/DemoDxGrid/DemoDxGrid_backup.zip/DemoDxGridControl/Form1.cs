﻿using DemoDxGridControl.Models;
using Microsoft.AspNet.SignalR.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.Enums;
using TableDependency.SqlClient.Base.EventArgs;

namespace DemoDxGridControl
{
    public partial class Form1 : Form
    {

        private string username { get; set; }
        private IHubProxy hubproxy { get; set; }
        const string ServerURL = "http://localhost:8235/signalr";
        private HubConnection connection { get; set; }
        string connection_string = @"Data Source=suwet_phr2\SQL2014;Initial Catalog = MyTestdb; Persist Security Info=True;User ID = sa; Password=1234qwer";

        public Form1()
        {
            InitializeComponent();

            Task.Run(async () => 
            {
                ThreadSafe(() => refresh_table());
                await ConnectAsync(); 
            });
        }

        private async Task ConnectAsync()
        {
            connection = new HubConnection(ServerURL.Trim());
            connection.Closed += Connection_Closed;
            hubproxy = connection.CreateHubProxy("NotiHub");
            hubproxy.On<Ticket, string>("ReceiveMessage", (entity, action_name)
                                      =>
            {
                ThreadSafe(() => 
                {
                    Debug.WriteLine(entity.CustomerNo + "  " + action_name + "\n");
                });
                
                ThreadSafe(() => 
                {
                    refresh_table();
                });
            });
            try
            {
                await connection.Start();
            }
            catch (HttpRequestException ex)
            {
                Debug.WriteLine("Unable to connect to server : Start server before connectiong clients.");
                return;

            }
            
        }

        private void Connection_Closed()
        {
           // this.Invoke((Action)(() => btn_send.Enabled = false));
            this.Invoke((Action)(() => Debug.WriteLine("You have been disconnected.")));
        }

       

        //common function 
        private void refresh_table()
        {
            string sql = "SELECT * FROM Ticket";
            SqlConnection connection = new SqlConnection(connection_string);
            SqlDataAdapter dataadapter = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "Ticket");
            connection.Close();
            ThreadSafe(() => ticket_grid.DataSource = ds);
            ThreadSafe(() => ticket_grid.DataMember = "Ticket");
        }
        public void log_file(string logText)
        {
            // logText += DateTime.Now.ToString() + Environment.NewLine + logText;
            //ThreadSafe(() => richTextBox1.AppendText(DateTime.Now.ToString("HH:mm:ss:fff") + "\t" + logText + Environment.NewLine));
            System.IO.File.AppendAllText(Application.StartupPath + "\\log.txt", logText);

        }
        private void ThreadSafe(MethodInvoker method)
        {
            try
            {
                if (InvokeRequired)
                    Invoke(method);
                else
                    method();
            }
            catch (ObjectDisposedException) { }
        }

        private  void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
