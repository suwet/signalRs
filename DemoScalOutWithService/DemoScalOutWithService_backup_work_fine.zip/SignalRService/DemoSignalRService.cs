﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SignalRService
{
    public partial class DemoSignalRService : ServiceBase
    {
        private HubServer hubserver;
        public DemoSignalRService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                hubserver = new HubServer();
                hubserver.StartSignalRServer();
                hubserver.Start_Table_Dependency();

                hubserver.Log_To_File("Start SignalR hub successfully.");
                hubserver.Log_To_File("Start Sql Dependency successfully.");
            }
            catch (Exception ex)
            {
                hubserver.Log_To_File(ex.Message);
                return;
            }
           
            
        }

        protected override void OnStop()
        {
            if (hubserver != null)
            {
                hubserver.Stop_Table_Dependency();
                hubserver.Log_To_File("stop table Dependency and signalR successfully");
            }

            hubserver = null;
        }
    }
}
